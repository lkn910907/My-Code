#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <time.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include "xenstore.h"

int main()
{
	FILE *fp;
	int i=0,j=0,len;
	char* rd;	//读取中断调节机制开关键值
	int N;	//记录虚拟机中使用的网口数目
	int interrupt[5];	//暂取虚拟机里最多5块网卡
    	char *affinity_old[5];  //保留未开启中断调节机制之前中断的CPU亲和度信息
	char *affinity_new[5]; 	//开启中断调节机制之后中断的CPU亲和度信息
	char buf[256]={0};
	char cmd[200];	//终端命令
	char path[5][100];
	const char *pathn="interrupt/Switch";
	char *p=NULL,*s=NULL;
	xs_transaction_t xt;
    	struct xs_handle *xh = xs_domain_open();  
    	
	if(!xh)
    	{
    		/*无法连接到XenStore*/
		printf("error\n");
		return ;
    	}
	
	if (!(fp = fopen("/proc/interrupts", "r"))) 
	{
        	printf("fopen failed.\n");
        	return -1;
    	}
	fgets(buf, 255, fp);	//过滤掉第一行的CPU栏信息
	while( fgets(buf, 255, fp)!= NULL )
	{	
		fgets(buf, 255, fp);
		//printf("%s",buf);
		p=buf;
		/*跳过空格*/
		while (isspace((int) *p))
            		p++;
		/*获取中断号，保存到s中*/
		s=p;
		while (*p && *p != ':')
            		p++;
		*p = '\0';
		p++;
		//printf("%s\n",s);
		//printf("%s",p);
		/*找到网卡的中断号*/
		if( strstr(p, "eth") == 0)
            		continue;
		printf("%s",s);
                printf("%s",p);
		/*字符串形式转换成整型*/
		interrupt[i]= atoi(s);
		//printf("%d\n",interrupt[i]);
		i++;
	}
	N=i;
	fclose(fp);
	//for(;j<N;j++)
	//	printf("%d\n",interrupt[j]);
  	
	/*获取开启中断调节机制之前，每一个网卡中断绑定的CPU位图*/
	for(j=0;j<N;j++)
	{
		sprintf( path[j],"/proc/irq/%d/smp_affinity",interrupt[j]);
		//printf("%s\n",path[j]);
		if (!(fp = fopen(path[j], "r")))
        	{
                	printf("fopen failed.\n");
                	return -1;
        	}
        	fgets(buf, 255, fp);
		//printf("%s\n",buf);
		p=buf;
                /*跳过空格*/
                while (isspace((int) *p))
                        p++;
		s=p;	
		/*该行有换行符，要过滤掉*/
		while (*p && *p!='\n')
                        p++;
                *p = '\0';
		//printf("%s\n",s);
		affinity_old[j]=s;
		printf("%s\n",affinity_old[j]);
	}
	fclose(fp);
	
	while(1)
	{
		xt=xs_transaction_start(xh);
        	if(!xt)
       		{	
            		printf("error\n");
            		return -1;
        	}	
		rd = xs_read(xh,xt,pathn,&len);
		xs_transaction_end(xh,xt,false);
		printf("%s",rd);
		if( !strcmp(rd,"1"))
		{
			printf("中断调节机制开启中\n");
		}
		else
		{
			/*检测到关闭中断调节机制，恢复中断原始的CPU位图*/
         		for(j=0;j<N;j++)
		        {		
		                 //affinity_old[j]="0001";       为了检查是否有效的测试
	             		sprintf( path[j],"/proc/irq/%d/smp_affinity",interrupt[j]);
		                sprintf(cmd,"echo \"%s\"> %s",affinity_old[j],path[j]);
                 		//printf("%s\n",cmd);
                 		system(cmd);
	    		 }
			printf("中断调节机制已关闭\n");
		}
		sleep(5);		
	}
	
	return 0;
}
